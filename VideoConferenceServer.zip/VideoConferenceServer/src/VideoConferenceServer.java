
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class VideoConferenceServer {
    private static final int SERVER_PORT = 5000;
    private static final int FORWARD_PORT = 6000;
    private static final int BUFFER_SIZE = 65507; // Max UDP packet size

    private DatagramSocket serverSocket;
    private DatagramSocket forwardingSocket;

    /** meeting id to conference participants ip addresses. */
    private Map<String, ArrayList<InetSocketAddress>> mapMeetingtoClients = new TreeMap<>();
    private ExecutorService executorService;

    public VideoConferenceServer() throws SocketException {
        serverSocket = new DatagramSocket(SERVER_PORT);
        forwardingSocket = new DatagramSocket(FORWARD_PORT);
        executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        System.out.println("Server started on port " + SERVER_PORT);
    }

    public synchronized void work(){
        byte[] receiveBuffer = new byte[BUFFER_SIZE];
        DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);

        try {
            serverSocket.receive(receivePacket);
            handlePacket(receivePacket);
        } catch (IOException e) {
            System.out.println("aaaa");
            e.printStackTrace();
        }
    }

    public void start() {
        while (true) {
            work();
        }
    }

    private void handlePacket(DatagramPacket packet) {
        String message = new String(packet.getData(), 0, packet.getLength());
        if (message.equals("REGISTERAMEETING")) {
            registerMeeting((InetSocketAddress) packet.getSocketAddress());
        } else if (message.startsWith("MEETINGID:")) {
            forwardPacket(packet);
        } else if (message.startsWith("JOINAMEETING:")){
            registerParticipant(packet);
        }
    }

    private void registerMeeting(InetSocketAddress address) {

        String uuid;
        do {
            uuid = UUIDGenerator.generateShortUUID();
        }
        while (mapMeetingtoClients.containsKey(uuid));

        mapMeetingtoClients.put(uuid, new ArrayList<>());
        mapMeetingtoClients.get(uuid).add(address);
        System.out.println("User " + address + " registered meeting: " + uuid);

        String data = "MEETINGID:" + uuid;
        DatagramPacket packet = new DatagramPacket(data.getBytes(), data.length(),
                address.getAddress(), address.getPort());

        try {
            serverSocket.send(packet);
        }
        catch (IOException ex){
            System.out.println("couldn't register meeting:" + ex);
        }
    }

    private void registerParticipant(DatagramPacket packet) {
        if (packet == null)
            return;
        String sMessage = new String(packet.getData(), 0, packet.getLength());

        InetSocketAddress oPacketSender = (InetSocketAddress) packet.getSocketAddress();
        String sMeetingID = sMessage.substring(13, 25);
        List<InetSocketAddress> aParticipants = mapMeetingtoClients.get(sMeetingID);

        if(!aParticipants.contains(oPacketSender)) {
            aParticipants.add(oPacketSender);
            System.out.println("joined participant" + oPacketSender.getAddress());

//            String message = "JOINED";
//            byte[] bytes = message.getBytes();
//            DatagramPacket sendingPacket = new DatagramPacket(bytes, bytes.length,
//                    new InetSocketAddress(packet.getAddress(), 5000));

//            try {
//                serverSocket.send(sendingPacket);
//            } catch (IOException ex) {
//                System.out.println("couldn't join to a meeting:" + ex);
//            }
        }
        else
            System.out.println("already participant" + oPacketSender.getAddress());
    }

    private synchronized void forwardPacket(DatagramPacket packet) {
        String sMessage = new String(packet.getData(), 0, packet.getLength());

        InetSocketAddress oPacketSender = (InetSocketAddress) packet.getSocketAddress();
        String sMeetingID = sMessage.substring(10, 22);
        List<InetSocketAddress> aParticipants = mapMeetingtoClients.get(sMeetingID);

        if (aParticipants == null)
            return;

        for (int i = 0; i < aParticipants.size(); i++) {
            if (!aParticipants.get(i).getAddress().equals(oPacketSender.getAddress())) {
                try {
                    byte[] data = sMessage.substring(12).getBytes();
                    int length = sMessage.length() - 12;
                    DatagramPacket forwardPacket = new DatagramPacket(data, length, aParticipants.get(i).getAddress(), FORWARD_PORT);
                    forwardingSocket.send(forwardPacket);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public static void main(String[] args) {
        try {
            new VideoConferenceServer().start();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }
}