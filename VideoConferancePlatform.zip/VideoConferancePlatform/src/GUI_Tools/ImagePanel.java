
package GUI_Tools;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

public class ImagePanel extends JPanel{
    private final BufferedImage image;

    public ImagePanel(String filepath) throws IOException{
        image = ImageIO.read(new File(filepath));
        setBackground(new Color(217, 143, 106));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, getWidth() / 2 - image.getWidth() / 2, 20, this);
    }
}
