import org.opencv.core.Mat;

import java.awt.image.BufferedImage;

public interface ICAMHook {
    //void UpdateFrame(Mat mat);
    void UpdateFrame(BufferedImage mat);
}
