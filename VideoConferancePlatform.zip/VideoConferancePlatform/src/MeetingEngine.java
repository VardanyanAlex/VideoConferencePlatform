import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Base64;

public class MeetingEngine {
    public static Runnable ListenMeeting;
    private static DatagramSocket socket;

    /**
     *
     * @return the meeting id.
     * @throws IOException, if failed to open a socket.
     */
    public static String OrganizeMeeting() throws IOException {
        socket = new DatagramSocket();

        Document doc = Document.getInstance();

        String data = "REGISTERAMEETING";
        DatagramPacket dgPacket = new DatagramPacket(data.getBytes(), data.length(), new InetSocketAddress(doc.getHostName(), doc.getHostListeningPort()));
        socket.send(dgPacket);

        byte[] receivedData = new byte[64];
        dgPacket = new DatagramPacket(receivedData, receivedData.length,
                dgPacket.getAddress(), dgPacket.getPort());

        socket.receive(dgPacket);
        String sMessage = new String(dgPacket.getData(), 0, dgPacket.getLength());
        if (!sMessage.startsWith("MEETINGID:") || sMessage.length() != 22)
            return null;

         return sMessage.substring(10, 22);
    }

    public static void SendFrameOverUDP(BufferedImage matFrame, String sMeetingID) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(matFrame, "jpg", baos);
            byte[] bytes = baos.toByteArray();

            byte[] imageData = ("MEETINGID:" + sMeetingID + Base64.getEncoder().encodeToString(bytes)).getBytes();

            Document doc = Document.getInstance();


            socket = new DatagramSocket();
            DatagramPacket dgPacket = new DatagramPacket(imageData, imageData.length, new InetSocketAddress(doc.getHostName(), doc.getHostListeningPort()));
            socket.send(dgPacket);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Runnable MakeMeetingListener(ICAMHook oHook, String sMeetingID){
        return new Runnable() {
            @Override
            public void run() {

                try {
                    Document doc = Document.getInstance();
                    socket = new DatagramSocket();
                    String data = "JOINAMEETING:" + sMeetingID;
                    DatagramPacket dgPacket = new DatagramPacket(data.getBytes(), data.length(), new InetSocketAddress(doc.getHostName(), doc.getHostListeningPort()));
                    socket.send(dgPacket);

                    DatagramSocket receivingSocket = new DatagramSocket(6000);
                    receivingSocket.setSoTimeout(10000);
                    while (true) {
                        try{
                            byte[] buffer = new byte[65507];
                            dgPacket = new DatagramPacket(buffer, buffer.length, new InetSocketAddress(doc.getHostName(), 6000));
                            receivingSocket.receive(dgPacket);

                            ByteArrayInputStream bytesStream = new ByteArrayInputStream(dgPacket.getData(), 0, dgPacket.getLength());
                            BufferedImage receivedImage = ImageIO.read(bytesStream);
                            oHook.UpdateFrame(receivedImage);
                        } catch (SocketException e) {
                            //throw new RuntimeException(e);
                        } catch (IOException e) {
                            //throw new RuntimeException(e);
                        }
                    }
                } catch (SocketException e) {
                    //throw new RuntimeException(e);
                } catch (IOException e) {
                    //throw new RuntimeException(e);
                }
            }
        };
    }
}
