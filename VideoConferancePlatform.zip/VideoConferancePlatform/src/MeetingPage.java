
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.DatagramPacket;

public class MeetingPage extends JPanel implements ICAMHook {
    private Camera              oCamera;
    private ParticipantView     jpParticipantsCameraView;
    private JButton             jbtnBacktoMainMenu;
    private String              sMeetingID;
    public MeetingPage() {
        SetupUI();
        SetupButtonConnections();
    }

    public void CreateMeeting() throws IOException{
        sMeetingID = MeetingEngine.OrganizeMeeting();
    }

    public void JoinMeeting(String sMeetingID) throws IOException{
        this.sMeetingID = sMeetingID;

        Runnable oListener =  MeetingEngine.MakeMeetingListener(jpParticipantsCameraView, this.sMeetingID);
        new Thread(oListener).start();
    }

    private void SetupUI(){
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        setAlignmentX(Component.CENTER_ALIGNMENT);
        setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);

        JPanel aCamerasPane = new JPanel();
        aCamerasPane.setLayout(new BoxLayout(aCamerasPane, BoxLayout.X_AXIS));
        aCamerasPane.setAlignmentX(CENTER_ALIGNMENT);

        oCamera = new Camera(this);
        oCamera.setAlignmentX(Component.CENTER_ALIGNMENT);
        oCamera.setAlignmentY(Component.CENTER_ALIGNMENT);
        oCamera.setMaximumSize(new Dimension(400, 480) );
        aCamerasPane.add(oCamera);

        jpParticipantsCameraView = new ParticipantView();
        jpParticipantsCameraView.setAlignmentX(Component.CENTER_ALIGNMENT);
        jpParticipantsCameraView.setAlignmentY(Component.CENTER_ALIGNMENT);
        jpParticipantsCameraView.setMaximumSize(new Dimension(400, 480) );
        aCamerasPane.add(jpParticipantsCameraView);

        add(aCamerasPane);

        add(Box.createRigidArea(new Dimension(10,20)));

        jbtnBacktoMainMenu = new JButton("Back to Main Menu");
        jbtnBacktoMainMenu.setAlignmentX(Component.CENTER_ALIGNMENT);
        jbtnBacktoMainMenu.setPreferredSize(new Dimension(70, 30));
        add(jbtnBacktoMainMenu);
    }
    private void SetupButtonConnections(){
        jbtnBacktoMainMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);

                oCamera.stop();
                try {
                    VideoConferencePlatform.getInstance().SetupEntryPage();
                }
                catch (IOException ex){
                    JOptionPane.showMessageDialog(getParent(), "Oops, Smth went wrong!!!");
                }
            }
        });
    }

    @Override
    public void UpdateFrame(BufferedImage bufImage) {
        if (sMeetingID == null) {
            JOptionPane.showMessageDialog(getParent(), "Oops, Smth went wrong!!!");
            return;
        }

        MeetingEngine.SendFrameOverUDP(bufImage, sMeetingID);
    }
}
