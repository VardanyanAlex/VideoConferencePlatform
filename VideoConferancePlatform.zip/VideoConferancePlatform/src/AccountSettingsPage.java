
import javax.print.Doc;
import javax.swing.*;
import javax.swing.text.NumberFormatter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.text.NumberFormat;

public class AccountSettingsPage extends JPanel {
    private JTextField              jtfUsernameTextField;
    private JTextField              jtfServerHostField;
    private JTextField              jtfServerPortField;
    private JButton                 jbtnCancel;
    private JButton                 jbtnSave;

    public AccountSettingsPage(){
        SetupUI();
        SetupButtonsConnections();
    }
    public void SetupUI(){
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
        setAlignmentX(Component.CENTER_ALIGNMENT);
        setAlignmentY(Component.CENTER_ALIGNMENT);

        JLabel jlblAccountSettings = new JLabel("Account Settings");
        jlblAccountSettings.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        add(jlblAccountSettings);

        JPanel jpContextPanel = new JPanel();
        jpContextPanel.setLayout(new GridLayout(4, 2, 20, 5));
        jpContextPanel.setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
        jpContextPanel.setMaximumSize(new Dimension(550, 200) );
        jpContextPanel.setBorder(BorderFactory.createEmptyBorder(60, 20, 20, 20));

        JLabel jlblUserName = new JLabel("UserName: ");
        jpContextPanel.add(jlblUserName);

        Document doc = Document.getInstance();

        jtfUsernameTextField = new JTextField(doc.getUsername());
        jtfUsernameTextField.setMaximumSize(new Dimension(200, 10));
        jpContextPanel.add(jtfUsernameTextField);

        JLabel jlblServerHost = new JLabel("Server hostname or IP address: ");
        jpContextPanel.add(jlblServerHost);

        jtfServerHostField = new JTextField(doc.getHostName());
        jtfServerHostField.setMaximumSize(new Dimension(200, 10));
        jpContextPanel.add(jtfServerHostField);

        JLabel jlblServerPort = new JLabel("Server Listening Port: ");
        jpContextPanel.add(jlblServerPort);

        jtfServerPortField = new JTextField(Integer.toString(doc.getHostListeningPort()));
        jtfServerPortField.setMaximumSize(new Dimension(200, 10));
        jpContextPanel.add(jtfServerPortField);

        add(jpContextPanel);

        JPanel jpCancelSave = new JPanel();
        jpCancelSave.setLayout(new BoxLayout(jpCancelSave, BoxLayout.X_AXIS));
        jpCancelSave.setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
        jpCancelSave.setAlignmentX(Component.CENTER_ALIGNMENT);
        jpCancelSave.setAlignmentY(Component.CENTER_ALIGNMENT);

        jbtnCancel = new JButton("Cancel");
        jbtnCancel.setAlignmentX(Component.CENTER_ALIGNMENT);
        jbtnCancel.setPreferredSize(new Dimension(70, 30));
        jpCancelSave.add(jbtnCancel, Component.CENTER_ALIGNMENT);

        jpCancelSave.add(Box.createRigidArea(new Dimension(10,5)));

        jbtnSave = new JButton("Save");
        jbtnSave.setAlignmentX(Component.CENTER_ALIGNMENT);
        jbtnSave.setPreferredSize(new Dimension(70, 30));
        jpCancelSave.add(jbtnSave, Component.CENTER_ALIGNMENT);

        add(jpCancelSave);
    }

    private void SetupButtonsConnections(){
        jbtnSave.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);

                try {
                    Document doc = Document.getInstance();

                    if (jtfUsernameTextField.getText().isEmpty() || jtfServerHostField.getText().isEmpty())
                        JOptionPane.showMessageDialog(getParent(), "Oops, All fields must be filled!!!");

                    doc.setUsername(jtfUsernameTextField.getText());
                    doc.setHostName(jtfServerHostField.getText());
                    Integer portNumber = Integer.parseInt(jtfServerPortField.getText());
                    if (portNumber == null || portNumber < 1025 || portNumber > 65535)
                        JOptionPane.showMessageDialog(getParent(), "Oops, Port number should be an integer from the range [1025 ; 65535]!");
                    doc.setHostListeningPort(portNumber);

                    VideoConferencePlatform.getInstance().SetupEntryPage();
                }
                catch (IOException ex){
                    JOptionPane.showMessageDialog(getParent(), "Oops, Smth went wrong: " + ex.getMessage());
                }
                catch (Exception ex){
                    JOptionPane.showMessageDialog(getParent(),"Oops, Smth went wrong: " + ex.getMessage());
                }

            }
        });

        jbtnCancel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);

                try {
                    VideoConferencePlatform.getInstance().SetupEntryPage();
                }
                catch (IOException ex){
                    JOptionPane.showMessageDialog(getParent(), "Oops, Smth went wrong!!!");
                }
            }
        });
    }
}
