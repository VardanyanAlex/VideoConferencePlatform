import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class JoinMeetingPage extends JPanel {
    private JTextField              jtfMeetingIDField;
    private JButton                 jbtnCancel;
    private JButton                 jbtnJoin;

    public JoinMeetingPage(){
        SetupUI();
        SetupButtonsConnections();
    }
    public void SetupUI(){
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
        setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel jlblEnterMeetingID = new JLabel("Enter the meeting ID");
        jlblEnterMeetingID.setAlignmentX(Component.CENTER_ALIGNMENT);
        jlblEnterMeetingID.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        add(jlblEnterMeetingID, Component.CENTER_ALIGNMENT);


        jtfMeetingIDField = new JTextField();
        jtfMeetingIDField.setMaximumSize(new Dimension(100, 20));
        add(jtfMeetingIDField, Component.CENTER_ALIGNMENT);

        add(Box.createRigidArea(new Dimension(10,5)));


        JPanel jpCancelJoin = new JPanel();
        jpCancelJoin.setMaximumSize(new Dimension(150, 40));
        jpCancelJoin.setLayout(new BoxLayout(jpCancelJoin, BoxLayout.X_AXIS));
        jpCancelJoin.setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
        jpCancelJoin.setAlignmentX(Component.CENTER_ALIGNMENT);

        jbtnCancel = new JButton("Cancel");
        jbtnCancel.setPreferredSize(new Dimension(70, 30));
        jpCancelJoin.add(jbtnCancel);

        jpCancelJoin.add(Box.createRigidArea(new Dimension(10,20)));

        jbtnJoin = new JButton("Join");
        jbtnJoin.setPreferredSize(new Dimension(70, 30));
        jpCancelJoin.add(jbtnJoin);

        add(jpCancelJoin);
    }

    private void SetupButtonsConnections(){
        jbtnJoin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);

                try {
                    String sMeetingID = jtfMeetingIDField.getText();
                    if(sMeetingID.isEmpty()){
                        JOptionPane.showMessageDialog(getParent(), "Enter the meeting ID");
                        return;
                    }

                    jtfMeetingIDField.setText("");
                    VideoConferencePlatform.getInstance().JoinMeeting(sMeetingID);
                }
                catch (Exception ex){
                    JOptionPane.showMessageDialog(getParent(),"Oops, Smth went wrong: " + ex.getMessage());
                }

            }
        });

        jbtnCancel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);

                try {
                    jtfMeetingIDField.setText("");
                    VideoConferencePlatform.getInstance().SetupEntryPage();
                }
                catch (IOException ex){
                    JOptionPane.showMessageDialog(getParent(), "Oops, Smth went wrong!!!");
                }
            }
        });
    }
}
